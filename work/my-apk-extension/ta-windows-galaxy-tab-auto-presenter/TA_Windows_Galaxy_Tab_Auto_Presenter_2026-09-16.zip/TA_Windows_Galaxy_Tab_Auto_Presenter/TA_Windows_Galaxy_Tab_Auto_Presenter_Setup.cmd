@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TA_Windows_Galaxy_Tab_Auto_Presenter_Setup.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo SETUP FAILED. Error code: %RC%
  pause
)
exit /b %RC%

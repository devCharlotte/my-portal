TA Windows Galaxy Tab Auto Presenter
====================================

VERSION
-------
2026-09-16-v3

SETUP
-----
Run:
TA_Windows_Galaxy_Tab_Auto_Presenter_Setup.cmd

AUTOMATIC USE
-------------
After setup, connect the Galaxy Tab S7+ with a USB-C DATA cable.
The presentation starts automatically.

PRESENTATION MODE
-----------------
1920 x 1080
--flex-display
--no-vd-system-decorations
--keep-active
--no-audio
--window-title=Flexcil-Presentation

No crop.
No stretched rendering.

V3 CHANGES
----------
- Replaced the previous Watcher script with a simpler Auto script.
- All scripts and launchers are ASCII-only.
- Starts only once per USB connection.
- No repeated scrcpy restart loop.
- Keeps the window-title argument as one token.
- Cleans older startup entries during setup.
- Uses one unified program/folder/file prefix.

STATUS
------
TA_Windows_Galaxy_Tab_Auto_Presenter_Status.cmd

MANUAL START
------------
TA_Windows_Galaxy_Tab_Auto_Presenter_Run_Now.cmd

UNINSTALL
---------
TA_Windows_Galaxy_Tab_Auto_Presenter_Uninstall.cmd

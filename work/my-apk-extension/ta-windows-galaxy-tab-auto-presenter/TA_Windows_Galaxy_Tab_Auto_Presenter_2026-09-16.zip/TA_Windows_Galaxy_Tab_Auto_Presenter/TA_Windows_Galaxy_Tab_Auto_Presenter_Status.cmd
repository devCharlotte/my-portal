@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TA_Windows_Galaxy_Tab_Auto_Presenter_Status.ps1"

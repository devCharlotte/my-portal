$ErrorActionPreference = "SilentlyContinue"

Add-Type -AssemblyName System.Windows.Forms

$AppId = "TA_Windows_Galaxy_Tab_Auto_Presenter"
$AppName = "TA Windows Galaxy Tab Auto Presenter"

$Root = Join-Path $env:LOCALAPPDATA $AppId
$Runtime = Join-Path $Root "scrcpy"
$Adb = Join-Path $Runtime "adb.exe"
$Scrcpy = Join-Path $Runtime "scrcpy.exe"

$LogDir = Join-Path $Root "logs"
$LogFile = Join-Path $LogDir "auto.log"

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

function Write-Log([string]$Text) {
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    Add-Content -Path $LogFile -Value "[$Timestamp] $Text" -Encoding UTF8
}

$Mutex = New-Object System.Threading.Mutex(
    $false,
    "Local\TA_Windows_Galaxy_Tab_Auto_Presenter_Auto"
)

if (-not $Mutex.WaitOne(0, $false)) {
    exit
}

function Get-AdbDeviceLines {
    try {
        & $Adb start-server 2>$null | Out-Null
        return @(& $Adb devices -l 2>$null)
    }
    catch {
        Write-Log "adb devices failed."
        return @()
    }
}

function Get-AuthorizedTablet {
    foreach ($Line in (Get-AdbDeviceLines)) {
        if ($Line -match '^([^\s:]+)\s+device\s*(.*)$') {
            $Serial = $Matches[1]

            try {
                $Model = (& $Adb -s $Serial shell getprop ro.product.model 2>$null | Out-String).Trim()
                $Characteristics = (& $Adb -s $Serial shell getprop ro.build.characteristics 2>$null | Out-String).Trim()

                if (($Model -match '^SM-T97') -or ($Characteristics -match '(?i)tablet')) {
                    return [PSCustomObject]@{
                        Serial = $Serial
                        Model = $Model
                    }
                }
            }
            catch {}
        }
    }

    return $null
}

function Has-UnauthorizedDevice {
    try {
        foreach ($Line in @(& $Adb devices 2>$null)) {
            if ($Line -match '^([^\s:]+)\s+unauthorized$') {
                return $true
            }
        }
    }
    catch {}

    return $false
}

function Find-FlexcilPackage([string]$Serial) {
    try {
        $PackageLine = @(& $Adb -s $Serial shell pm list packages 2>$null) |
            Where-Object { $_ -match '(?i)flexcil' } |
            Select-Object -First 1

        if ($PackageLine) {
            return (($PackageLine -replace '^package:', '').Trim())
        }
    }
    catch {}

    return $null
}

function Open-FlexcilOnTablet([string]$Serial) {
    $PackageName = Find-FlexcilPackage $Serial

    if (-not $PackageName) {
        Write-Log "Flexcil package not found."
        return
    }

    try {
        $Resolved = @(
            & $Adb -s $Serial shell cmd package resolve-activity --brief $PackageName 2>$null
        )

        $Component = $Resolved |
            Where-Object { $_ -match '/' } |
            Select-Object -Last 1

        if ($Component) {
            $Component = $Component.Trim()

            & $Adb -s $Serial shell am start --display 0 -n $Component 2>$null |
                Out-Null

            Write-Log "Flexcil opened on display 0."
            return
        }
    }
    catch {}

    try {
        & $Adb -s $Serial shell monkey -p $PackageName -c android.intent.category.LAUNCHER 1 2>$null |
            Out-Null

        Write-Log "Flexcil opened with fallback."
    }
    catch {}
}

function Start-Presentation([string]$Serial, [string]$Model) {
    $ArgumentList = @(
        "--serial=$Serial",
        "--new-display=1920x1080/240",
        "--flex-display",
        "--no-vd-system-decorations",
        "--keep-active",
        "--no-audio",
        "--window-title=Flexcil-Presentation"
    )

    try {
        $Process = Start-Process `
            -FilePath $Scrcpy `
            -WorkingDirectory $Runtime `
            -ArgumentList $ArgumentList `
            -PassThru

        Write-Log "scrcpy started. PID=$($Process.Id), model=$Model, serial=$Serial"

        Start-Sleep -Milliseconds 1800

        if (-not (Get-Process -Id $Process.Id -ErrorAction SilentlyContinue)) {
            Write-Log "scrcpy exited during startup."
            return $false
        }

        Open-FlexcilOnTablet $Serial
        return $true
    }
    catch {
        Write-Log "scrcpy start error: $($_.Exception.Message)"
        return $false
    }
}

Write-Log "Auto script started."

$LastSerial = $null
$StartedForConnection = $false
$UnauthorizedNoticeShown = $false

while ($true) {
    if (-not ((Test-Path $Adb) -and (Test-Path $Scrcpy))) {
        Write-Log "Runtime files are missing."
        Start-Sleep -Seconds 3
        continue
    }

    if (Has-UnauthorizedDevice) {
        if (-not $UnauthorizedNoticeShown) {
            $UnauthorizedNoticeShown = $true

            [System.Windows.Forms.MessageBox]::Show(
                "Allow USB debugging on the Galaxy Tab. The presentation will continue automatically after authorization.",
                $AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }

        Start-Sleep -Seconds 1
        continue
    }

    $UnauthorizedNoticeShown = $false
    $Tablet = Get-AuthorizedTablet

    if (-not $Tablet) {
        if ($LastSerial) {
            Write-Log "Tablet disconnected: $LastSerial"
        }

        $LastSerial = $null
        $StartedForConnection = $false

        Start-Sleep -Seconds 1
        continue
    }

    if ($Tablet.Serial -ne $LastSerial) {
        $LastSerial = $Tablet.Serial
        $StartedForConnection = $false

        Write-Log "Tablet connected. model=$($Tablet.Model), serial=$($Tablet.Serial)"
    }

    if (-not $StartedForConnection) {
        $StartedForConnection = $true

        $Started = Start-Presentation `
            -Serial $Tablet.Serial `
            -Model $Tablet.Model

        if (-not $Started) {
            Write-Log "Presentation startup failed. Waiting for USB reconnect."
        }
    }

    Start-Sleep -Seconds 1
}

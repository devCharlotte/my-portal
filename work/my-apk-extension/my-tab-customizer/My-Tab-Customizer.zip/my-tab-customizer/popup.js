'use strict';

const STORAGE_KEYS = {
  categories: 'tabCategories',
  categoryGroupMap: 'categoryGroupMap'
};

const COLOR_LABELS = {
  grey: '회색', blue: '파랑', red: '빨강', yellow: '노랑', green: '초록',
  pink: '분홍', purple: '보라', cyan: '청록', orange: '주황'
};

const elements = {
  tabList: document.querySelector('#tabList'),
  tabListEmpty: document.querySelector('#tabListEmpty'),
  tabCount: document.querySelector('#tabCount'),
  refreshTabsButton: document.querySelector('#refreshTabsButton'),

  categorySelect: document.querySelector('#categorySelect'),
  deleteCategoryButton: document.querySelector('#deleteCategoryButton'),
  newCategoryName: document.querySelector('#newCategoryName'),
  newCategoryColor: document.querySelector('#newCategoryColor'),
  addCategoryButton: document.querySelector('#addCategoryButton'),

  resetButton: document.querySelector('#resetButton'),
  status: document.querySelector('#status')
};

let activeTab = null;
let currentWindowId = null;
let categories = [];
let isEditing = false; // an inline title editor is currently open

/* ---------------------------------------------------------------- helpers */

function setStatus(message, type = '') {
  elements.status.textContent = message;
  elements.status.className = `status ${type}`.trim();
}

function colorLabel(color) {
  return COLOR_LABELS[color] || color;
}

function isScriptableUrl(url = '') {
  return /^https?:\/\//i.test(url) || /^file:\/\//i.test(url);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || typeof tab.id !== 'number') {
    throw new Error('활성 탭을 찾을 수 없음.');
  }
  return tab;
}

/* ------------------------------------------ injected page-context functions */

// Title-only override with a MutationObserver so SPA title changes stick.
function injectSetTitle(title) {
  const root = document.documentElement;
  const head = document.head || root;

  if (!Object.prototype.hasOwnProperty.call(root.dataset, 'jhTabOriginalTitle')) {
    root.dataset.jhTabOriginalTitle = document.title;
  }
  if (window.__jhTabTitleObserver) {
    window.__jhTabTitleObserver.disconnect();
  }

  let titleNode = document.querySelector('title');
  if (!titleNode) {
    titleNode = document.createElement('title');
    head.appendChild(titleNode);
  }
  titleNode.textContent = title;
  document.title = title;

  const observer = new MutationObserver(() => {
    if (document.title !== title) document.title = title;
  });
  observer.observe(titleNode, { childList: true, subtree: true, characterData: true });
  window.__jhTabTitleObserver = observer;

  return document.title;
}

// Restore the original title (and any favicons saved by older versions).
function injectResetAll() {
  const root = document.documentElement;
  const head = document.head || root;

  if (window.__jhTabTitleObserver) {
    window.__jhTabTitleObserver.disconnect();
    delete window.__jhTabTitleObserver;
  }
  if (Object.prototype.hasOwnProperty.call(root.dataset, 'jhTabOriginalTitle')) {
    document.title = root.dataset.jhTabOriginalTitle;
    delete root.dataset.jhTabOriginalTitle;
  }
  if (Object.prototype.hasOwnProperty.call(root.dataset, 'jhTabOriginalFavicons')) {
    document.querySelectorAll('link[rel*="icon"]').forEach((link) => link.remove());
    try {
      const originals = JSON.parse(root.dataset.jhTabOriginalFavicons || '[]');
      for (const item of originals) {
        const link = document.createElement('link');
        link.rel = item.rel || 'icon';
        if (item.href) link.setAttribute('href', item.href);
        if (item.type) link.type = item.type;
        if (item.sizes) link.setAttribute('sizes', item.sizes);
        head.appendChild(link);
      }
    } catch (_error) { /* ignore malformed legacy value */ }
    delete root.dataset.jhTabOriginalFavicons;
  }
  return { title: document.title };
}

/* --------------------------------------------------------- group management */

async function saveOriginalGroupState(tab) {
  const key = `groupState:${tab.id}`;
  const stored = await chrome.storage.local.get(key);
  if (stored[key]) return stored[key];

  let state;
  if (tab.groupId === chrome.tabGroups.TAB_GROUP_ID_NONE || tab.groupId === -1) {
    state = { createdByExtension: true, currentGroupId: null };
  } else {
    const group = await chrome.tabGroups.get(tab.groupId);
    state = {
      createdByExtension: false,
      currentGroupId: tab.groupId,
      originalGroupId: tab.groupId,
      originalTitle: group.title || '',
      originalColor: group.color,
      originalCollapsed: group.collapsed
    };
  }
  await chrome.storage.local.set({ [key]: state });
  return state;
}

async function updateSavedGroupState(tabId, groupId, mode, categoryId = '') {
  const key = `groupState:${tabId}`;
  const stored = await chrome.storage.local.get(key);
  const state = stored[key] || { createdByExtension: true };
  state.currentGroupId = groupId;
  state.appliedMode = mode;
  state.categoryId = categoryId;
  await chrome.storage.local.set({ [key]: state });
}

async function getCategoryGroupMap() {
  const stored = await chrome.storage.local.get(STORAGE_KEYS.categoryGroupMap);
  return stored[STORAGE_KEYS.categoryGroupMap] || {};
}

async function saveCategoryGroupMap(map) {
  await chrome.storage.local.set({ [STORAGE_KEYS.categoryGroupMap]: map });
}

async function findExistingCategoryGroup(tab, category) {
  const map = await getCategoryGroupMap();
  const mapKey = `${tab.windowId}:${category.id}`;
  const mappedGroupId = map[mapKey];

  if (typeof mappedGroupId === 'number') {
    try {
      const mappedGroup = await chrome.tabGroups.get(mappedGroupId);
      if (mappedGroup.windowId === tab.windowId) return { groupId: mappedGroupId, map, mapKey };
    } catch (_error) {
      delete map[mapKey];
    }
  }

  const groups = await chrome.tabGroups.query({ windowId: tab.windowId });
  const matched = groups.find((group) => group.title === category.name && group.color === category.color);
  if (matched) {
    map[mapKey] = matched.id;
    await saveCategoryGroupMap(map);
    return { groupId: matched.id, map, mapKey };
  }
  return { groupId: null, map, mapKey };
}

async function customizeCategory(tab, category) {
  await saveOriginalGroupState(tab);
  const found = await findExistingCategoryGroup(tab, category);
  let groupId = found.groupId;

  if (typeof groupId === 'number') {
    const latestTab = await chrome.tabs.get(tab.id);
    if (latestTab.groupId !== groupId) {
      await chrome.tabs.group({ tabIds: [tab.id], groupId });
    }
  } else {
    groupId = await chrome.tabs.group({
      tabIds: [tab.id],
      createProperties: { windowId: tab.windowId }
    });
  }

  await chrome.tabGroups.update(groupId, {
    title: category.name,
    color: category.color,
    collapsed: false
  });

  found.map[found.mapKey] = groupId;
  await saveCategoryGroupMap(found.map);
  await updateSavedGroupState(tab.id, groupId, 'category', category.id);
  return groupId;
}

async function restoreGroup(tab) {
  const key = `groupState:${tab.id}`;
  const stored = await chrome.storage.local.get(key);
  const state = stored[key];
  if (!state) {
    // Never touched by the extension → just ungroup if it happens to be grouped.
    const latestTab = await chrome.tabs.get(tab.id);
    if (latestTab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE && latestTab.groupId !== -1) {
      await chrome.tabs.ungroup(tab.id);
    }
    return;
  }

  if (state.createdByExtension) {
    const latestTab = await chrome.tabs.get(tab.id);
    const stillInExtGroup = typeof state.currentGroupId !== 'number' || latestTab.groupId === state.currentGroupId;
    if (stillInExtGroup && latestTab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE && latestTab.groupId !== -1) {
      await chrome.tabs.ungroup(tab.id);
    }
  } else if (typeof state.originalGroupId === 'number') {
    try {
      const latestTab = await chrome.tabs.get(tab.id);
      if (latestTab.groupId !== state.originalGroupId) {
        await chrome.tabs.group({ tabIds: [tab.id], groupId: state.originalGroupId });
      }
      await chrome.tabGroups.update(state.originalGroupId, {
        title: state.originalTitle,
        color: state.originalColor,
        collapsed: state.originalCollapsed
      });
    } catch (_error) { /* original group may be gone */ }
  }

  await chrome.storage.local.remove(key);
}

/* ------------------------------------------------------- category storage UI */

function normalizeCategoryName(name) {
  return name.trim().replace(/\s+/g, ' ');
}

function createCategoryId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `category-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function loadCategories() {
  const stored = await chrome.storage.local.get(STORAGE_KEYS.categories);
  categories = Array.isArray(stored[STORAGE_KEYS.categories]) ? stored[STORAGE_KEYS.categories] : [];
  renderCategorySelect();
}

function renderCategorySelect(selectedId = '') {
  elements.categorySelect.replaceChildren();
  const emptyOption = document.createElement('option');
  emptyOption.value = '';
  emptyOption.textContent = '카테고리 선택…';
  elements.categorySelect.appendChild(emptyOption);

  for (const category of categories) {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = `${category.name} · ${colorLabel(category.color)}`;
    elements.categorySelect.appendChild(option);
  }

  elements.categorySelect.value =
    selectedId && categories.some((c) => c.id === selectedId) ? selectedId : '';
  elements.deleteCategoryButton.disabled = !elements.categorySelect.value;
}

async function addCategory() {
  const name = normalizeCategoryName(elements.newCategoryName.value);
  if (!name) {
    setStatus('카테고리 이름 입력 필요.', 'error');
    elements.newCategoryName.focus();
    return;
  }
  const duplicate = categories.find((c) => c.name.toLocaleLowerCase() === name.toLocaleLowerCase());
  if (duplicate) {
    renderCategorySelect(duplicate.id);
    setStatus(`이미 저장된 “${duplicate.name}” 카테고리.`);
    return;
  }
  const category = { id: createCategoryId(), name, color: elements.newCategoryColor.value };
  categories.push(category);
  await chrome.storage.local.set({ [STORAGE_KEYS.categories]: categories });
  renderCategorySelect(category.id);
  elements.newCategoryName.value = '';
  await renderTabList();
  setStatus(`“${category.name}” 카테고리 추가됨. 탭 목록에서 지정 가능.`, 'success');
}

async function deleteSelectedCategory() {
  const selectedId = elements.categorySelect.value;
  if (!selectedId) return;
  const category = categories.find((c) => c.id === selectedId);
  categories = categories.filter((c) => c.id !== selectedId);
  await chrome.storage.local.set({ [STORAGE_KEYS.categories]: categories });

  const map = await getCategoryGroupMap();
  for (const key of Object.keys(map)) {
    if (key.endsWith(`:${selectedId}`)) delete map[key];
  }
  await saveCategoryGroupMap(map);

  renderCategorySelect();
  await renderTabList();
  setStatus(`“${category?.name || '선택한'}” 카테고리 삭제됨. 기존 Chrome 그룹은 유지.`, 'success');
}

/* ------------------------------------------------------------- tab list view */

async function renderTabList(animate = false) {
  if (isEditing) return; // don't blow away an in-progress rename

  const tabs = await chrome.tabs.query({ currentWindow: true });
  currentWindowId = tabs[0]?.windowId ?? currentWindowId;

  let groupById = new Map();
  if (currentWindowId != null) {
    try {
      const groups = await chrome.tabGroups.query({ windowId: currentWindowId });
      groupById = new Map(groups.map((g) => [g.id, g]));
    } catch (_error) { /* tabGroups may be unavailable on some tabs */ }
  }

  elements.tabList.replaceChildren();
  elements.tabCount.textContent = tabs.length ? `${tabs.length}개` : '';
  elements.tabListEmpty.classList.toggle('hidden', tabs.length > 0);

  tabs.forEach((tab, index) => {
    const row = buildTabRow(tab, groupById.get(tab.groupId));
    if (animate) {
      row.classList.add('enter');
      row.style.animationDelay = `${Math.min(index, 12) * 26}ms`;
    }
    elements.tabList.appendChild(row);
  });
}

function buildTabRow(tab, group) {
  const row = document.createElement('div');
  row.className = 'tab-row' + (tab.active ? ' active' : '');
  row.setAttribute('role', 'listitem');
  row.dataset.tabId = String(tab.id);

  // Favicon
  const favicon = document.createElement('img');
  favicon.className = 'tab-favicon';
  favicon.alt = '';
  if (tab.favIconUrl && /^(https?:|data:|chrome:)/.test(tab.favIconUrl)) {
    favicon.src = tab.favIconUrl;
    favicon.addEventListener('error', () => favicon.classList.add('no-image'), { once: true });
  } else {
    favicon.classList.add('no-image');
  }
  row.appendChild(favicon);

  // Title (double-click to edit)
  const title = document.createElement('span');
  title.className = 'tab-title';
  const displayTitle = tab.title || tab.url || '제목 없음';
  title.textContent = displayTitle;
  title.title = displayTitle;

  const editable = isScriptableUrl(tab.url);
  if (!editable) {
    title.classList.add('locked');
    title.title = '보호된 페이지: 이름 변경 불가';
  } else {
    title.addEventListener('dblclick', () => startInlineEdit(row, tab, title));
  }
  row.appendChild(title);

  // Group selector
  const select = document.createElement('select');
  select.className = 'tab-group-select';
  select.setAttribute('aria-label', `${displayTitle} 그룹`);

  const none = document.createElement('option');
  none.value = '';
  none.textContent = '그룹 없음';
  select.appendChild(none);

  for (const category of categories) {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = category.name;
    select.appendChild(option);
  }

  // Preselect the category matching this tab's actual Chrome group.
  let matchedCategory = null;
  if (group) {
    matchedCategory = categories.find((c) => c.name === group.title && c.color === group.color) || null;
  }
  select.value = matchedCategory ? matchedCategory.id : '';

  if (matchedCategory) {
    select.classList.add('has-group', `group-${matchedCategory.color}`);
  } else if (group) {
    select.classList.add('has-group', `group-${group.color}`);
  }

  select.addEventListener('change', () => onRowCategoryChange(tab, select.value));
  row.appendChild(select);

  return row;
}

function startInlineEdit(row, tab, titleSpan) {
  if (isEditing) return;
  isEditing = true;

  const original = tab.title || titleSpan.textContent || '';
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tab-title-input';
  input.maxLength = 200;
  input.value = original;

  row.replaceChild(input, titleSpan);
  input.focus();
  input.select();

  let settled = false;

  const finish = async (save) => {
    if (settled) return;
    settled = true;
    input.removeEventListener('keydown', onKeyDown);
    input.removeEventListener('blur', onBlur);

    const value = input.value.trim();
    row.replaceChild(titleSpan, input);
    isEditing = false;

    if (save && value && value !== original) {
      try {
        await commitRename(tab, value);
        tab.title = value;
        titleSpan.textContent = value;
        titleSpan.title = value;
        titleSpan.classList.add('renamed');
        setStatus(`탭 이름 “${value}”(으)로 변경됨.`, 'success');
      } catch (error) {
        setStatus(error?.message || '이름 변경 실패.', 'error');
      }
    } else {
      titleSpan.textContent = tab.title || original;
      titleSpan.title = titleSpan.textContent;
    }
  };

  const onKeyDown = (event) => {
    if (event.key === 'Enter') { event.preventDefault(); finish(true); }
    else if (event.key === 'Escape') { event.preventDefault(); finish(false); }
  };
  const onBlur = () => finish(true);

  input.addEventListener('keydown', onKeyDown);
  input.addEventListener('blur', onBlur);
}

async function commitRename(tab, title) {
  if (!isScriptableUrl(tab.url)) {
    throw new Error('이 페이지는 이름 변경 불가.');
  }
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: injectSetTitle,
    args: [title]
  });
}

async function onRowCategoryChange(tab, categoryId) {
  try {
    if (!categoryId) {
      await restoreGroup(tab);
      setStatus('그룹에서 제외됨.', 'success');
    } else {
      const category = categories.find((c) => c.id === categoryId);
      if (!category) throw new Error('카테고리를 찾을 수 없음.');
      await customizeCategory(tab, category);
      setStatus(`“${category.name}” 그룹에 추가됨.`, 'success');
    }
  } catch (error) {
    setStatus(error?.message || '그룹 변경 실패.', 'error');
  }
  await renderTabList();
}

/* --------------------------------------------------------------- reset (active) */

async function resetActiveTab() {
  elements.resetButton.disabled = true;
  setStatus('복원 중…');
  try {
    activeTab = await getActiveTab();
    if (!isScriptableUrl(activeTab.url)) {
      throw new Error('복원할 내용 없음.');
    }
    await chrome.scripting.executeScript({ target: { tabId: activeTab.id }, func: injectResetAll });
    await restoreGroup(activeTab);
    await renderTabList();
    setStatus('현재 탭 이름·그룹 복원됨.', 'success');
  } catch (error) {
    setStatus(error?.message || '복원 실패.', 'error');
  } finally {
    elements.resetButton.disabled = false;
  }
}

/* -------------------------------------------------------------------- startup */

async function initialize() {
  elements.categorySelect.addEventListener('change', () => {
    elements.deleteCategoryButton.disabled = !elements.categorySelect.value;
  });

  elements.newCategoryName.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { event.preventDefault(); addCategory(); }
  });

  elements.addCategoryButton.addEventListener('click', addCategory);
  elements.deleteCategoryButton.addEventListener('click', deleteSelectedCategory);
  elements.resetButton.addEventListener('click', resetActiveTab);
  elements.refreshTabsButton.addEventListener('click', async () => {
    await renderTabList();
    setStatus('탭 목록 새로고침됨.');
  });

  try {
    await loadCategories();
    activeTab = await getActiveTab();
    currentWindowId = activeTab.windowId;
    await renderTabList(true);

    if (!isScriptableUrl(activeTab.url)) {
      setStatus('현재 탭은 보호된 페이지. 복원은 일반 웹사이트에서 가능.');
    } else {
      setStatus('제목 더블클릭으로 이름 변경, 오른쪽에서 그룹 지정 가능.');
    }
  } catch (error) {
    setStatus(error?.message || '탭 정보를 읽을 수 없음.', 'error');
  }
}

initialize();

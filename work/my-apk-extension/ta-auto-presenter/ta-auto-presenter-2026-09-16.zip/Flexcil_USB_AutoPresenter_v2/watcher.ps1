﻿$ErrorActionPreference = "SilentlyContinue"

Add-Type -AssemblyName System.Windows.Forms

$Root = Join-Path $env:LOCALAPPDATA "FlexcilAutoPresenter"
$Runtime = Join-Path $Root "scrcpy"
$Adb = Join-Path $Runtime "adb.exe"
$Scrcpy = Join-Path $Runtime "scrcpy.exe"
$LogDir = Join-Path $Root "logs"
$Log = Join-Path $LogDir "watcher.log"
$PidFile = Join-Path $Root "scrcpy.pid"

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

function Write-Log([string]$Text) {
    $t = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    Add-Content -Path $Log -Value "[$t] $Text" -Encoding UTF8
}

$mutex = New-Object System.Threading.Mutex($false, "Local\FlexcilAutoPresenterWatcherV2")
if (-not $mutex.WaitOne(0, $false)) { exit }

function Get-AdbLines {
    try {
        & $Adb start-server 2>$null | Out-Null
        return @(& $Adb devices -l 2>$null)
    }
    catch {
        return @()
    }
}

function Get-Tablet {
    $lines = Get-AdbLines

    foreach ($line in $lines) {
        # USB serials only; skip network ADB entries containing colon.
        if ($line -match '^([^\s:]+)\s+device\s*(.*)$') {
            $serial = $Matches[1]

            try {
                $model = (& $Adb -s $serial shell getprop ro.product.model 2>$null | Out-String).Trim()
                $char  = (& $Adb -s $serial shell getprop ro.build.characteristics 2>$null | Out-String).Trim()

                if (($model -match '^SM-T97') -or ($char -match '(?i)tablet')) {
                    return [PSCustomObject]@{ Serial = $serial; Model = $model }
                }
            } catch {}
        }
    }

    return $null
}

function Has-Unauthorized {
    $lines = @(& $Adb devices 2>$null)
    foreach ($line in $lines) {
        if ($line -match '^([^\s:]+)\s+unauthorized$') { return $true }
    }
    return $false
}

function Is-PresentationRunning {
    if (-not (Test-Path $PidFile)) { return $false }

    try {
        $id = [int]((Get-Content $PidFile | Select-Object -First 1).Trim())
        $p = Get-Process -Id $id -ErrorAction Stop
        return ($p.ProcessName -eq "scrcpy")
    }
    catch {
        return $false
    }
}

function Find-FlexcilPackage([string]$Serial) {
    try {
        $packages = @(& $Adb -s $Serial shell pm list packages 2>$null)
        $line = $packages | Where-Object { $_ -match '(?i)flexcil' } | Select-Object -First 1
        if ($line) { return (($line -replace '^package:', '').Trim()) }
    } catch {}
    return $null
}

function Bring-FlexcilToPhysicalDisplay([string]$Serial) {
    $pkg = Find-FlexcilPackage $Serial
    if (-not $pkg) {
        Write-Log "Flexcil package not found."
        return
    }

    try {
        $resolved = @(& $Adb -s $Serial shell cmd package resolve-activity --brief $pkg 2>$null)
        $component = $resolved | Where-Object { $_ -match '/' } | Select-Object -Last 1

        if ($component) {
            $component = $component.Trim()
            & $Adb -s $Serial shell am start --display 0 -n $component 2>$null | Out-Null
            Write-Log "Flexcil moved/launched on display 0."
            return
        }
    } catch {}

    try {
        & $Adb -s $Serial shell monkey -p $pkg -c android.intent.category.LAUNCHER 1 2>$null | Out-Null
        Write-Log "Flexcil launched with fallback."
    } catch {}
}

function Start-Presentation($Tablet) {
    if (Is-PresentationRunning) { return }

    Remove-Item $PidFile -Force -ErrorAction SilentlyContinue

    $args = @(
        "--serial=$($Tablet.Serial)",
        "--new-display=1920x1080/240",
        "--flex-display",
        "--no-vd-system-decorations",
        "--keep-active",
        "--no-audio",
        "--window-title=Flexcil Presentation"
    )

    try {
        $p = Start-Process -FilePath $Scrcpy -WorkingDirectory $Runtime -ArgumentList $args -PassThru
        Set-Content -Path $PidFile -Value $p.Id -Encoding ASCII
        Write-Log "scrcpy started: PID=$($p.Id), model=$($Tablet.Model), serial=$($Tablet.Serial)"

        Start-Sleep -Milliseconds 1800
        Bring-FlexcilToPhysicalDisplay $Tablet.Serial
    }
    catch {
        Write-Log "scrcpy start failed: $($_.Exception.Message)"
    }
}

Write-Log "Watcher started."

$noticeShown = $false

while ($true) {
    if (-not ((Test-Path $Adb) -and (Test-Path $Scrcpy))) {
        Write-Log "Runtime missing."
        Start-Sleep -Seconds 3
        continue
    }

    if (Has-Unauthorized) {
        if (-not $noticeShown) {
            $noticeShown = $true
            [System.Windows.Forms.MessageBox]::Show(
                "On the Galaxy Tab, allow USB debugging. Check 'Always allow from this computer' if available. The watcher will continue automatically after authorization.",
                "Flexcil USB Auto Presenter",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
        Start-Sleep -Milliseconds 800
        continue
    }
    else {
        $noticeShown = $false
    }

    $tablet = Get-Tablet

    if ($tablet) {
        if (-not (Is-PresentationRunning)) {
            Start-Presentation $tablet
        }
    }
    else {
        if (-not (Is-PresentationRunning)) {
            Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
        }
    }

    Start-Sleep -Milliseconds 900
}

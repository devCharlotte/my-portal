Flexcil USB Auto Presenter v2

IMPORTANT
=========
This version fixes the broken Korean/UTF-8 .cmd files from the previous package.
All .cmd launchers are plain ASCII with Windows CRLF line endings and NO UTF-8 BOM.

SETUP
=====
1. Extract the ZIP completely.
2. Double-click: setup.cmd
3. Wait for "Setup completed".
4. Connect Galaxy Tab S7+ with a USB-C DATA cable.

AFTER SETUP
===========
You do not need to run anything manually.
At Windows login, a hidden watcher starts automatically.
When the Galaxy Tab is connected through USB, it starts:

  scrcpy
  --new-display=1920x1080/240
  --flex-display
  --no-vd-system-decorations
  --keep-active
  --no-audio

No crop.
No stretched rendering.

ANDROID SECURITY
================
On a new PC, Android may ask once:
"Allow USB debugging?"

Check:
"Always allow from this computer"
then press Allow.

DIAGNOSTICS
===========
If USB is connected but nothing opens:
double-click status.cmd

Copy the entire status window and send it to ChatGPT.

MANUAL TEST
===========
run_now.cmd

UNINSTALL
=========
uninstall.cmd

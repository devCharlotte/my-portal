﻿$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms

$AppName = "Flexcil USB Auto Presenter"
$Root = Join-Path $env:LOCALAPPDATA "FlexcilAutoPresenter"
$Runtime = Join-Path $Root "scrcpy"
$LogDir = Join-Path $Root "logs"
$Watcher = Join-Path $Root "watcher.ps1"
$Runner = Join-Path $Root "watcher_hidden.vbs"
$Startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
$StartupRunner = Join-Path $Startup "FlexcilAutoPresenter.vbs"

$ScrcpyExe = Join-Path $Runtime "scrcpy.exe"
$AdbExe = Join-Path $Runtime "adb.exe"

$ScrcpyUrl = "https://github.com/Genymobile/scrcpy/releases/download/v4.1/scrcpy-win64-v4.1.zip"
$ScrcpySha256 = "5b12172b3264b2889f4583ee64752ce832e29bc8b1089dca81093459697165db"

function Show-Info([string]$Text) {
    [System.Windows.Forms.MessageBox]::Show(
        $Text,
        $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Find-ExistingScrcpy {
    $preferred = @(
        (Join-Path $env:USERPROFILE "Downloads\scrcpy-portable\scrcpy-win64-v4.1\scrcpy.exe"),
        (Join-Path $env:USERPROFILE "Downloads\scrcpy-win64-v4.1\scrcpy.exe"),
        (Join-Path $env:USERPROFILE "scrcpy-portable\scrcpy-win64-v4.1\scrcpy.exe")
    )

    foreach ($p in $preferred) {
        if (Test-Path $p) { return Get-Item $p }
    }

    $searchRoots = @(
        (Join-Path $env:USERPROFILE "Downloads"),
        (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages")
    )

    foreach ($r in $searchRoots) {
        if (-not (Test-Path $r)) { continue }
        try {
            $x = Get-ChildItem -Path $r -Filter "scrcpy.exe" -File -Recurse -ErrorAction SilentlyContinue |
                 Where-Object { $_.FullName -match "(?i)scrcpy" } |
                 Sort-Object LastWriteTime -Descending |
                 Select-Object -First 1
            if ($x) { return $x }
        } catch {}
    }

    return $null
}

function Copy-ScrcpyRuntime([System.IO.FileInfo]$Exe) {
    if (-not $Exe) { return $false }
    New-Item -ItemType Directory -Path $Runtime -Force | Out-Null
    Copy-Item -Path (Join-Path $Exe.Directory.FullName "*") -Destination $Runtime -Recurse -Force
    return ((Test-Path $ScrcpyExe) -and (Test-Path $AdbExe))
}

function Download-ScrcpyRuntime {
    $tmp = Join-Path $env:TEMP ("FlexcilAutoPresenter_" + [Guid]::NewGuid().ToString("N"))
    $zip = Join-Path $tmp "scrcpy.zip"
    $out = Join-Path $tmp "out"

    try {
        New-Item -ItemType Directory -Path $tmp -Force | Out-Null
        New-Item -ItemType Directory -Path $out -Force | Out-Null

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $ScrcpyUrl -OutFile $zip -UseBasicParsing

        $actual = (Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $ScrcpySha256) {
            throw "scrcpy download hash verification failed."
        }

        Expand-Archive -Path $zip -DestinationPath $out -Force

        $exe = Get-ChildItem -Path $out -Filter "scrcpy.exe" -File -Recurse |
               Select-Object -First 1
        if (-not $exe) { throw "scrcpy.exe was not found in the downloaded package." }

        if (-not (Copy-ScrcpyRuntime $exe)) {
            throw "Could not prepare the scrcpy runtime."
        }
    }
    finally {
        Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
}

try {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    New-Item -ItemType Directory -Path $Runtime -Force | Out-Null
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

    # Copy the watcher script shipped next to this installer.
    $WatcherSource = Join-Path $PSScriptRoot "watcher.ps1"
    if (-not (Test-Path $WatcherSource)) {
        throw "watcher.ps1 is missing from the extracted package."
    }
    Copy-Item $WatcherSource $Watcher -Force

    # Reuse the already-working scrcpy if present. Download only if necessary.
    if (-not ((Test-Path $ScrcpyExe) -and (Test-Path $AdbExe))) {
        $existing = Find-ExistingScrcpy
        if ($existing) {
            if (-not (Copy-ScrcpyRuntime $existing)) {
                throw "Found scrcpy but failed to copy its runtime."
            }
        }
        else {
            Download-ScrcpyRuntime
        }
    }

    # Hidden launcher for the background watcher.
    $runnerText = @"
Set sh = CreateObject("WScript.Shell")
sh.Run "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$Watcher""", 0, False
"@
    [System.IO.File]::WriteAllText($Runner, $runnerText, [System.Text.Encoding]::ASCII)

    # Kill older watcher instances from previous attempts.
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.CommandLine -and
            ($_.CommandLine -match "FlexcilAutoPresenter") -and
            ($_.CommandLine -match "watcher\.ps1")
        } |
        ForEach-Object {
            Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
        }

    # Use Startup folder (no admin privileges, reliable for a user session).
    Copy-Item $Runner $StartupRunner -Force

    # Start watcher immediately.
    Start-Process -FilePath "wscript.exe" -ArgumentList "`"$StartupRunner`""

    # Desktop diagnostic shortcut.
    $desktop = [Environment]::GetFolderPath("Desktop")
    $statusScript = Join-Path $Root "status.ps1"
    Copy-Item (Join-Path $PSScriptRoot "status.ps1") $statusScript -Force

    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut((Join-Path $desktop "Flexcil AutoPresenter Status.lnk"))
    $lnk.TargetPath = "powershell.exe"
    $lnk.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$statusScript`""
    $lnk.WorkingDirectory = $Root
    $lnk.Save()

    Show-Info @"
Setup completed.

From now on:
1. Connect the Galaxy Tab S7+ with a USB-C data cable.
2. The Flexcil Presentation window should open automatically.

The automatic presentation mode is:
1920 x 1080 + flex-display
(no crop, no stretched rendering)

On a new PC, Android may ask once for USB debugging authorization.
Check "Always allow from this computer" and tap Allow.
"@
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        $_.Exception.Message,
        "$AppName - Setup error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

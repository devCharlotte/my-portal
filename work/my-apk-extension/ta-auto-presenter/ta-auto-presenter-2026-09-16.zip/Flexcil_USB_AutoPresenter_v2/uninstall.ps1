﻿$ErrorActionPreference = "SilentlyContinue"

$Root = Join-Path $env:LOCALAPPDATA "FlexcilAutoPresenter"
$Startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
$StartupRunner = Join-Path $Startup "FlexcilAutoPresenter.vbs"
$Desktop = [Environment]::GetFolderPath("Desktop")
$StatusShortcut = Join-Path $Desktop "Flexcil AutoPresenter Status.lnk"

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
    Where-Object {
        $_.CommandLine -and
        ($_.CommandLine -match "FlexcilAutoPresenter") -and
        ($_.CommandLine -match "watcher\.ps1")
    } |
    ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }

$pidFile = Join-Path $Root "scrcpy.pid"
if (Test-Path $pidFile) {
    try {
        $id = [int]((Get-Content $pidFile | Select-Object -First 1).Trim())
        Stop-Process -Id $id -Force -ErrorAction SilentlyContinue
    } catch {}
}

Remove-Item $StartupRunner -Force -ErrorAction SilentlyContinue
Remove-Item $StatusShortcut -Force -ErrorAction SilentlyContinue
Remove-Item $Root -Recurse -Force -ErrorAction SilentlyContinue

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show(
    "Flexcil USB Auto Presenter was removed.",
    "Flexcil USB Auto Presenter",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null

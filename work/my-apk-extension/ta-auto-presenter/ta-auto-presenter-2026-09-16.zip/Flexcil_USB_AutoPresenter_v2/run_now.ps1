﻿$ErrorActionPreference = "Stop"

$Root = Join-Path $env:LOCALAPPDATA "FlexcilAutoPresenter"
$Runtime = Join-Path $Root "scrcpy"
$Adb = Join-Path $Runtime "adb.exe"
$Scrcpy = Join-Path $Runtime "scrcpy.exe"

if (-not ((Test-Path $Adb) -and (Test-Path $Scrcpy))) {
    throw "Flexcil Auto Presenter is not installed. Run setup.cmd first."
}

& $Adb start-server 2>$null | Out-Null
$lines = @(& $Adb devices -l 2>$null)
$serial = $null

foreach ($line in $lines) {
    if ($line -match '^([^\s:]+)\s+device\s*(.*)$') {
        $candidate = $Matches[1]
        $model = (& $Adb -s $candidate shell getprop ro.product.model 2>$null | Out-String).Trim()
        $char  = (& $Adb -s $candidate shell getprop ro.build.characteristics 2>$null | Out-String).Trim()
        if (($model -match '^SM-T97') -or ($char -match '(?i)tablet')) {
            $serial = $candidate
            break
        }
    }
}

if (-not $serial) {
    throw "Galaxy Tab was not detected by ADB."
}

$args = @(
    "--serial=$serial",
    "--new-display=1920x1080/240",
    "--flex-display",
    "--no-vd-system-decorations",
    "--keep-active",
    "--no-audio",
    "--window-title=Flexcil Presentation"
)

Start-Process -FilePath $Scrcpy -WorkingDirectory $Runtime -ArgumentList $args

﻿$ErrorActionPreference = "SilentlyContinue"

$Root = Join-Path $env:LOCALAPPDATA "FlexcilAutoPresenter"
$Runtime = Join-Path $Root "scrcpy"
$Adb = Join-Path $Runtime "adb.exe"
$Scrcpy = Join-Path $Runtime "scrcpy.exe"
$Watcher = Join-Path $Root "watcher.ps1"
$Log = Join-Path $Root "logs\watcher.log"
$Startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
$StartupRunner = Join-Path $Startup "FlexcilAutoPresenter.vbs"

Write-Host ""
Write-Host "============================================================"
Write-Host "Flexcil USB Auto Presenter - STATUS"
Write-Host "============================================================"
Write-Host ""
Write-Host "Root      : $Root"
Write-Host "scrcpy    : $(Test-Path $Scrcpy)"
Write-Host "adb       : $(Test-Path $Adb)"
Write-Host "watcher   : $(Test-Path $Watcher)"
Write-Host "startup   : $(Test-Path $StartupRunner)"
Write-Host ""

Write-Host "[Watcher process]"
$watchers = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
    Where-Object {
        $_.CommandLine -and
        ($_.CommandLine -match "FlexcilAutoPresenter") -and
        ($_.CommandLine -match "watcher\.ps1")
    }

if ($watchers) {
    $watchers | ForEach-Object {
        Write-Host "RUNNING PID=$($_.ProcessId)"
        Write-Host $_.CommandLine
    }
}
else {
    Write-Host "NOT RUNNING"
}

Write-Host ""
Write-Host "[ADB]"
if (Test-Path $Adb) {
    & $Adb start-server 2>$null | Out-Null
    & $Adb devices -l
}
else {
    Write-Host "adb.exe not found"
}

Write-Host ""
Write-Host "[Recent log]"
if (Test-Path $Log) {
    Get-Content $Log -Tail 50
}
else {
    Write-Host "No log yet."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "Copy this entire window if you need help diagnosing the setup."
Write-Host "============================================================"
Write-Host ""
Read-Host "Press Enter to close"

@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo SETUP FAILED. Error code: %RC%
  echo Run status.cmd after setup succeeds, or send this console output for diagnosis.
  pause
)
exit /b %RC%

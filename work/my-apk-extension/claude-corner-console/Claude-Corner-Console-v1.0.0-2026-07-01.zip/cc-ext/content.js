/* ================================================================
   Claude Corner Console — content script (runs inside claude.ai)
   - Reads REAL usage from the Settings > Usage page (DOM scrape)
   - Session gauge, weekly per-model bars, plan badge, reset times
   - Peak-hours banner (computed locally, Pacific time)
   - Local activity heatmap (samples stored locally, never sent anywhere)
   - Command / prompt library: copy or insert into the chat composer
   ================================================================ */
(function () {
  "use strict";
  if (window.__ccConsoleLoaded) return;
  window.__ccConsoleLoaded = true;

  const S = chrome.storage.local;

  /* ---------- default command library ---------- */
  const SEED_CMDS = [
    // Slash commands
    { id: 101, cat: "Claude Code · 슬래시", text: "/usage",   desc: "세션·주간 한도, 활동 통계" },
    { id: 102, cat: "Claude Code · 슬래시", text: "/status",  desc: "현재 상태·남은 한도" },
    { id: 103, cat: "Claude Code · 슬래시", text: "/context", desc: "컨텍스트 창 사용량 시각화" },
    { id: 104, cat: "Claude Code · 슬래시", text: "/cost",    desc: "이번 세션 비용" },
    { id: 105, cat: "Claude Code · 슬래시", text: "/clear",   desc: "대화·컨텍스트 초기화" },
    { id: 106, cat: "Claude Code · 슬래시", text: "/compact", desc: "대화를 요약해 컨텍스트 절약" },
    { id: 107, cat: "Claude Code · 슬래시", text: "/model",   desc: "사용 모델 전환" },
    { id: 108, cat: "Claude Code · 슬래시", text: "/config",  desc: "설정 열기" },
    { id: 109, cat: "Claude Code · 슬래시", text: "/init",    desc: "CLAUDE.md 프로젝트 메모리 생성" },
    { id: 110, cat: "Claude Code · 슬래시", text: "/memory",  desc: "CLAUDE.md 메모리 편집" },
    { id: 111, cat: "Claude Code · 슬래시", text: "/mcp",     desc: "MCP 서버 관리" },
    { id: 112, cat: "Claude Code · 슬래시", text: "/agents",  desc: "서브에이전트 설정" },
    { id: 113, cat: "Claude Code · 슬래시", text: "/review",  desc: "코드 리뷰 요청" },
    { id: 114, cat: "Claude Code · 슬래시", text: "/permissions", desc: "도구 권한 관리" },
    { id: 115, cat: "Claude Code · 슬래시", text: "/hooks",   desc: "훅 설정" },
    { id: 116, cat: "Claude Code · 슬래시", text: "/add-dir", desc: "작업 디렉터리 추가" },
    { id: 117, cat: "Claude Code · 슬래시", text: "/resume",  desc: "이전 대화 이어가기" },
    { id: 118, cat: "Claude Code · 슬래시", text: "/vim",     desc: "Vim 편집 모드 토글" },
    { id: 119, cat: "Claude Code · 슬래시", text: "/terminal-setup", desc: "터미널 단축키 설정" },
    { id: 120, cat: "Claude Code · 슬래시", text: "/doctor",  desc: "설치 상태 진단" },
    { id: 121, cat: "Claude Code · 슬래시", text: "/bug",     desc: "버그 신고" },
    // Terminal
    { id: 201, cat: "Claude Code · 터미널", text: "claude",        desc: "대화형 세션 시작" },
    { id: 202, cat: "Claude Code · 터미널", text: "claude -c",     desc: "직전 대화 이어서 계속" },
    { id: 203, cat: "Claude Code · 터미널", text: "claude -r",     desc: "이전 세션 선택해 재개" },
    { id: 204, cat: "Claude Code · 터미널", text: "claude -p \"작업 설명\"", desc: "헤드리스(비대화) 실행" },
    { id: 205, cat: "Claude Code · 터미널", text: "claude update", desc: "최신 버전으로 업데이트" },
    { id: 206, cat: "Claude Code · 터미널", text: "claude mcp add", desc: "MCP 서버 추가" },
    // Input tricks
    { id: 301, cat: "Claude Code · 입력 트릭", text: "@경로/파일", desc: "파일·폴더 참조" },
    { id: 302, cat: "Claude Code · 입력 트릭", text: "!명령어",    desc: "셸 명령 바로 실행(bash 모드)" },
    { id: 303, cat: "Claude Code · 입력 트릭", text: "#내용",      desc: "CLAUDE.md 메모리에 바로 추가" },
    { id: 304, cat: "Claude Code · 입력 트릭", text: "Esc",        desc: "생성 중단" },
    { id: 305, cat: "Claude Code · 입력 트릭", text: "Esc Esc",    desc: "이전 메시지로 되돌아가 편집" },
    { id: 306, cat: "Claude Code · 입력 트릭", text: "Shift+Tab",  desc: "자동수락 / 플랜 모드 전환" },
    // Own snippets
    { id: 401, cat: "내 스니펫", text: "자주 쓰는 프롬프트를 여기에 저장하세요", desc: "+ 로 추가, ✎ 로 수정" }
  ];

  let state = { cmds: SEED_CMDS.slice(), usage: null, samples: [], heat: {}, ui: {} };

  /* ---------- load ---------- */
  S.get(["cmds", "usage", "samples", "heat", "ui"], (r) => {
    if (r.cmds) state.cmds = r.cmds;
    if (r.usage) state.usage = r.usage;
    if (r.samples) state.samples = r.samples;
    if (r.heat) state.heat = r.heat;
    if (r.ui) state.ui = r.ui;
    build();
    render();
    tryScrape();
  });

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.cmds) state.cmds = ch.cmds.newValue || [];
    if (ch.usage) state.usage = ch.usage.newValue || null;
    if (ch.heat) state.heat = ch.heat.newValue || {};
    if (ch.ui) state.ui = ch.ui.newValue || {};
    render();
  });

  /* ================= USAGE SCRAPER ================= */
  // Reads the visible numbers on Settings > Usage. Best-effort, language-agnostic.
  //
  // The page has two sections: "현재 세션"(session) and "주간 한도"(weekly). We split
  // the text at the weekly heading and parse each region separately, so a session
  // number can never be mislabeled/misclassified as a weekly one (or vice-versa).
  // Within a region, each "N% 사용됨" is paired with the NEAREST preceding label and
  // reset line — not the left-most one in a wide window, which caused session/weekly
  // values to swap and labels/reset times to bleed across sections.
  const CC_PCT   = /(\d{1,3})\s*%\s*(?:사용됨|used)/;
  const CC_LABEL = /현재 세션|주간 한도|모든 모델|Opus[^\n]*|Sonnet[^\n]*|Haiku[^\n]*|current session|weekly limit|all models/i;
  const CC_RESET = /[^\n]*(?:재설정|resets?)[^\n]*/i;

  // last (nearest-preceding) match of kwRe within region[0..endIdx]
  function nearestBefore(region, endIdx, kwRe) {
    const slice = region.slice(0, endIdx);
    const g = new RegExp(kwRe.source, "gi");
    let m, last = "";
    while ((m = g.exec(slice))) { last = m[0]; if (m.index === g.lastIndex) g.lastIndex++; }
    return last.trim();
  }

  function parseUsageRegion(region, fallbackLabel) {
    const out = [];
    const g = new RegExp(CC_PCT.source, "gi");
    let m;
    while ((m = g.exec(region))) {
      const pct = Math.min(100, parseInt(m[1], 10));
      const label = nearestBefore(region, m.index, CC_LABEL) || fallbackLabel;
      const reset = nearestBefore(region, m.index, CC_RESET);
      out.push({ pct, label, reset });
    }
    return out;
  }

  function scrapeUsage() {
    const body = document.body ? document.body.innerText : "";
    if (!/(사용됨|used)/i.test(body) || !/%/.test(body)) return null;

    // Split into session vs weekly regions at the weekly-limit heading.
    const wMatch = body.match(/주간 한도|weekly limit/i);
    const wIdx = wMatch ? wMatch.index : null;
    const sessionText = wIdx != null ? body.slice(0, wIdx) : body;
    const weeklyText  = wIdx != null ? body.slice(wIdx) : "";

    const sItems = parseUsageRegion(sessionText, "현재 세션");
    const wItems = weeklyText ? parseUsageRegion(weeklyText, "모든 모델") : [];

    let session, weekly;
    if (sItems.length) {
      session = sItems.find((i) => /현재 세션|current session/i.test(i.label)) || sItems[0];
      weekly = wItems.length ? wItems : sItems.filter((i) => i !== session);
    } else if (wItems.length) {
      session = { pct: 0, label: "현재 세션", reset: "" };
      weekly = wItems;
    } else {
      return null;
    }

    const plan = (body.match(/Max\s*\(?\s*\d+x\s*\)?|Max\b|Pro\b|Team\b|Enterprise\b/i) || [])[0] || "";
    return { plan: plan.trim(), session, weekly, at: Date.now() };
  }

  function tryScrape() {
    let u;
    try { u = scrapeUsage(); } catch (e) { u = null; }
    if (!u) return;
    state.usage = u;
    // log activity sample + heatmap
    logSample(u.session ? u.session.pct : null);
    S.set({ usage: u });
    render();
  }

  function logSample(sessionPct) {
    const now = Date.now();
    const last = state.samples[state.samples.length - 1];
    if (last && now - last.t < 4 * 60 * 1000) return; // dedupe ~4min
    // heatmap: mark active hour when session usage climbs
    if (last && sessionPct != null && sessionPct > last.p) {
      const d = new Date();
      const key = d.getDay() + "-" + d.getHours();
      state.heat[key] = (state.heat[key] || 0) + 1;
      S.set({ heat: state.heat });
    }
    state.samples.push({ t: now, p: sessionPct == null ? -1 : sessionPct });
    if (state.samples.length > 400) state.samples = state.samples.slice(-400);
    S.set({ samples: state.samples });
  }

  // re-scrape when the usage page renders async
  const onUsagePage = () => /\/settings\/usage/.test(location.pathname);
  let mo;
  function watchUsage() {
    if (mo) mo.disconnect();
    if (!onUsagePage()) return;
    let t;
    mo = new MutationObserver(() => { clearTimeout(t); t = setTimeout(tryScrape, 500); });
    mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(tryScrape, 800);
  }
  watchUsage();
  // SPA navigation
  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) { lastPath = location.pathname; watchUsage(); }
  }, 1000);

  /* ================= PEAK HOURS (Pacific) ================= */
  function laParts(date) {
    const f = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Los_Angeles", weekday: "short", hour: "numeric", hour12: false
    });
    const parts = f.formatToParts(date);
    const wd = parts.find((p) => p.type === "weekday").value;
    let hr = parseInt(parts.find((p) => p.type === "hour").value, 10);
    if (hr === 24) hr = 0;
    const dowMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    return { dow: dowMap[wd], hour: hr };
  }
  function isPeakAt(date) {
    const { dow, hour } = laParts(date);
    return dow >= 1 && dow <= 5 && hour >= 5 && hour < 11; // Mon–Fri 05–11 PT
  }
  function peakInfo() {
    const now = new Date();
    const peak = isPeakAt(now);
    let step = new Date(now.getTime());
    const cap = now.getTime() + 8 * 24 * 3600 * 1000;
    while (step.getTime() < cap && isPeakAt(step) === peak) {
      step = new Date(step.getTime() + 60 * 1000);
    }
    return { peak, msToFlip: step.getTime() - now.getTime() };
  }

  /* ================= WIDGET DOM ================= */
  let el, reopenBtn;
  function build() {
    if (document.getElementById("cc-console")) return;

    reopenBtn = document.createElement("button");
    reopenBtn.id = "cc-reopen";
    reopenBtn.title = "Corner Console 열기";
    reopenBtn.textContent = "◱";
    reopenBtn.addEventListener("click", () => setCollapsed(false));
    document.documentElement.appendChild(reopenBtn);

    el = document.createElement("div");
    el.id = "cc-console";
    el.innerHTML = `
      <header id="cc-head">
        <span class="cc-dot"></span>
        <h1>Corner Console <span id="cc-plan"></span></h1>
        <button class="cc-x" id="cc-collapse" title="접기">–</button>
      </header>
      <div class="cc-tabs">
        <button class="cc-tab active" data-v="usage">사용량</button>
        <button class="cc-tab" data-v="cmds">명령어</button>
      </div>
      <div class="cc-body">
        <div class="cc-view active" id="cc-usage"></div>
        <div class="cc-view" id="cc-cmds">
          <div class="cc-search-row">
            <input class="cc-search" id="cc-search" placeholder="명령어 검색…">
            <button class="cc-add" id="cc-add" title="추가">+</button>
          </div>
          <div id="cc-form"></div>
          <div id="cc-list"></div>
        </div>
      </div>`;
    document.documentElement.appendChild(el);

    el.querySelectorAll(".cc-tab").forEach((t) =>
      t.addEventListener("click", () => {
        el.querySelectorAll(".cc-tab").forEach((x) => x.classList.remove("active"));
        el.querySelectorAll(".cc-view").forEach((x) => x.classList.remove("active"));
        t.classList.add("active");
        el.querySelector("#cc-" + t.dataset.v).classList.add("active");
      }));

    el.querySelector("#cc-collapse").addEventListener("click", () => setCollapsed(true));
    el.querySelector("#cc-search").addEventListener("input", renderCmds);
    el.querySelector("#cc-add").addEventListener("click", () => openForm(null));

    restorePosition();
    makeDraggable(el.querySelector("#cc-head"));
    if (state.ui.collapsed) setCollapsed(true);
    setInterval(renderUsage, 60 * 1000); // keep peak countdown fresh
  }

  function setCollapsed(v) {
    state.ui.collapsed = v;
    el.style.display = v ? "none" : "flex";
    reopenBtn.style.display = v ? "flex" : "none";
    S.set({ ui: state.ui });
  }

  function restorePosition() {
    if (state.ui.right != null) { el.style.right = state.ui.right + "px"; el.style.bottom = state.ui.bottom + "px"; }
  }
  function makeDraggable(handle) {
    let sx, sy, sr, sb, on = false;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      on = true; handle.classList.add("grabbing");
      sx = e.clientX; sy = e.clientY;
      const r = el.getBoundingClientRect();
      sr = window.innerWidth - r.right; sb = window.innerHeight - r.bottom;
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!on) return;
      const right = Math.max(6, sr - (e.clientX - sx));
      const bottom = Math.max(6, sb - (e.clientY - sy));
      el.style.right = right + "px"; el.style.bottom = bottom + "px";
    });
    window.addEventListener("mouseup", () => {
      if (!on) return;
      on = false; handle.classList.remove("grabbing");
      const r = el.getBoundingClientRect();
      state.ui.right = Math.round(window.innerWidth - r.right);
      state.ui.bottom = Math.round(window.innerHeight - r.bottom);
      S.set({ ui: state.ui });
    });
  }

  /* ================= RENDER ================= */
  function render() { renderUsage(); renderCmds(); }

  function renderUsage() {
    if (!el) return;
    const planEl = el.querySelector("#cc-plan");
    const box = el.querySelector("#cc-usage");
    const u = state.usage;
    const pk = peakInfo();

    const banner = `
      <div class="cc-peak ${pk.peak ? "on" : "off"}">
        <span class="cc-peak-tag">${pk.peak ? "피크 시간대" : "여유 시간대"}</span>
        <span class="cc-peak-sub">${pk.peak ? "채팅 세션 소모 빠름" : "지금이 무거운 작업 적기"} · ${fmtDur(pk.msToFlip)} 후 전환</span>
      </div>`;

    if (!u) {
      planEl.textContent = "";
      box.innerHTML = banner + `
        <div class="cc-hint">아직 실제 사용량을 못 읽었어요. 아래 버튼으로 사용량 페이지를 한 번 열면 자동으로 읽어와 여기에 표시됩니다.</div>
        <button class="cc-refresh" id="cc-open">사용량 페이지 열기 →</button>` + heatmapHTML();
      const b = box.querySelector("#cc-open");
      if (b) b.onclick = () => location.assign("https://claude.ai/settings/usage");
      return;
    }

    planEl.textContent = u.plan ? "· " + u.plan : "";
    const s = u.session || { pct: 0, reset: "" };
    const gaugePct = s.pct;
    const gaugeColor = gaugePct >= 85 ? "var(--amber)" : "var(--clay)";
    const circ = 2 * Math.PI * 34;
    const dash = (gaugePct / 100) * circ;

    box.innerHTML =
      banner +
      `<div class="cc-gauge-wrap">
        <svg class="cc-gauge" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="34" fill="none" stroke="var(--panel-2)" stroke-width="8"/>
          <circle cx="40" cy="40" r="34" fill="none" stroke="${gaugeColor}" stroke-width="8"
            stroke-linecap="round" stroke-dasharray="${dash} ${circ}" transform="rotate(-90 40 40)"/>
          <text x="40" y="38" text-anchor="middle" class="cc-gauge-num">${gaugePct}%</text>
          <text x="40" y="52" text-anchor="middle" class="cc-gauge-cap">세션</text>
        </svg>
        <div class="cc-gauge-side">
          <div class="cc-label">현재 세션 · 5시간</div>
          <div class="cc-reset">${esc(s.reset || "리셋 정보 없음")}</div>
        </div>
      </div>` +
      (u.weekly && u.weekly.length
        ? `<div class="cc-cat" style="margin-top:14px">주간 한도</div>` +
          u.weekly.map((w) => {
            const hot = w.pct >= 85 ? " hot" : "";
            return `<div class="cc-meter">
              <div class="cc-meter-top">
                <span class="cc-label">${esc(w.label || "모델")}</span>
                <span class="cc-pct">${w.pct}%</span>
              </div>
              <div class="cc-bar${hot}"><i style="width:${w.pct}%"></i></div>
              ${w.reset ? `<div class="cc-reset">${esc(w.reset)}</div>` : ""}
            </div>`;
          }).join("")
        : "") +
      `<div class="cc-updated">${agoText(u.at)} 업데이트</div>
       <button class="cc-refresh" id="cc-open">사용량 새로고침 →</button>` +
      heatmapHTML();

    const b = box.querySelector("#cc-open");
    if (b) b.onclick = () => location.assign("https://claude.ai/settings/usage");
  }

  function heatmapHTML() {
    const days = ["일", "월", "화", "수", "목", "금", "토"];
    let max = 1;
    Object.values(state.heat).forEach((v) => { if (v > max) max = v; });
    let cells = "";
    for (let d = 0; d < 7; d++) {
      cells += `<div class="cc-hm-row"><span class="cc-hm-day">${days[d]}</span>`;
      for (let h = 0; h < 24; h++) {
        const v = state.heat[d + "-" + h] || 0;
        const a = v ? 0.18 + 0.82 * (v / max) : 0;
        cells += `<i class="cc-hm-cell" style="background:${a ? `rgba(217,119,87,${a.toFixed(2)})` : "var(--panel-2)"}" title="${days[d]} ${h}시 · ${v}"></i>`;
      }
      cells += `</div>`;
    }
    return `<div class="cc-cat" style="margin-top:16px">활동 히트맵 <span style="font-weight:400;text-transform:none">· 로컬 기록</span></div>
      <div class="cc-heat">${cells}</div>`;
  }

  /* ================= COMMANDS ================= */
  let editing = null;
  function renderCmds() {
    if (!el) return;
    const listEl = el.querySelector("#cc-list");
    const q = el.querySelector("#cc-search").value.trim().toLowerCase();
    const items = state.cmds.filter((c) =>
      !q || c.text.toLowerCase().includes(q) || (c.desc || "").toLowerCase().includes(q) || (c.cat || "").toLowerCase().includes(q));
    if (!items.length) {
      listEl.innerHTML = `<div class="cc-empty">${q ? "일치하는 명령어가 없어요." : "명령어가 없어요. + 로 추가하세요."}</div>`;
      return;
    }
    const cats = [...new Set(items.map((c) => c.cat))];
    listEl.innerHTML = cats.map((cat) =>
      `<div class="cc-cat">${esc(cat)}</div>` +
      items.filter((c) => c.cat === cat).map((c) =>
        `<div class="cc-cmd" data-copy="${esc(c.text)}">
          <div class="cc-cmd-main">
            <div class="cc-cmd-text">${esc(c.text)}</div>
            ${c.desc ? `<div class="cc-cmd-desc">${esc(c.desc)}</div>` : ""}
          </div>
          <div class="cc-tools">
            <button data-ins="${c.id}" title="채팅창에 삽입">↳</button>
            <button data-edit="${c.id}" title="수정">✎</button>
            <button data-del="${c.id}" title="삭제">✕</button>
          </div>
        </div>`).join("")
    ).join("");

    listEl.querySelectorAll(".cc-cmd").forEach((node) => {
      node.addEventListener("click", (e) => {
        if (e.target.closest("button")) return;
        copyText(node.dataset.copy, node);
      });
    });
    listEl.querySelectorAll("[data-ins]").forEach((b) =>
      b.addEventListener("click", () => insertToComposer(cmdById(+b.dataset.ins).text, b.closest(".cc-cmd"))));
    listEl.querySelectorAll("[data-edit]").forEach((b) =>
      b.addEventListener("click", () => openForm(+b.dataset.edit)));
    listEl.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", () => { state.cmds = state.cmds.filter((x) => x.id !== +b.dataset.del); S.set({ cmds: state.cmds }); }));
  }
  const cmdById = (id) => state.cmds.find((c) => c.id === id) || { text: "" };

  function openForm(id) {
    editing = id;
    const c = id ? cmdById(id) : { cat: "", text: "", desc: "" };
    const cats = [...new Set(state.cmds.map((x) => x.cat))];
    const slot = el.querySelector("#cc-form");
    slot.innerHTML = `
      <div class="cc-form">
        <input class="mono" id="cf-text" placeholder="명령어 / 프롬프트" value="${esc(c.text)}">
        <input id="cf-desc" placeholder="설명 (선택)" value="${esc(c.desc)}">
        <input id="cf-cat" list="cf-cats" placeholder="분류" value="${esc(c.cat)}">
        <datalist id="cf-cats">${cats.map((x) => `<option value="${esc(x)}">`).join("")}</datalist>
        <div class="cc-form-btns">
          <button class="cc-save" id="cf-save">${id ? "저장" : "추가"}</button>
          <button class="cc-cancel" id="cf-cancel">취소</button>
        </div>
      </div>`;
    slot.querySelector("#cf-text").focus();
    slot.querySelector("#cf-save").onclick = () => {
      const text = slot.querySelector("#cf-text").value.trim();
      const desc = slot.querySelector("#cf-desc").value.trim();
      const cat = slot.querySelector("#cf-cat").value.trim() || "내 스니펫";
      if (!text) return;
      if (editing) { const t = cmdById(editing); t.text = text; t.desc = desc; t.cat = cat; }
      else state.cmds.push({ id: Date.now(), text, desc, cat });
      S.set({ cmds: state.cmds }); slot.innerHTML = ""; editing = null; renderCmds();
    };
    slot.querySelector("#cf-cancel").onclick = () => { slot.innerHTML = ""; editing = null; };
  }

  function copyText(text, node) {
    const done = () => flash(node, "복사됨");
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done).catch(() => fb());
    else fb();
    function fb() { const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); done(); } catch (e) {} ta.remove(); }
  }

  function insertToComposer(text, node) {
    // Try the chat input (ProseMirror contenteditable or textarea). Fallback to copy.
    const ce = document.querySelector('div[contenteditable="true"].ProseMirror')
      || document.querySelector('div[contenteditable="true"]')
      || document.querySelector("textarea");
    if (ce) {
      ce.focus();
      try {
        if (ce.tagName === "TEXTAREA") {
          const start = ce.selectionStart || ce.value.length;
          ce.value = ce.value.slice(0, start) + text + ce.value.slice(ce.selectionEnd || start);
          ce.dispatchEvent(new Event("input", { bubbles: true }));
        } else {
          document.execCommand("insertText", false, text);
          ce.dispatchEvent(new InputEvent("input", { bubbles: true }));
        }
        flash(node, "삽입됨");
        return;
      } catch (e) { /* fall through */ }
    }
    copyText(text, node); // fallback
  }

  function flash(node, label) {
    if (!node) return;
    const t = document.createElement("span");
    t.className = "cc-copied"; t.textContent = label;
    node.appendChild(t); setTimeout(() => t.remove(), 900);
  }

  /* ================= helpers ================= */
  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function agoText(ts) {
    const m = Math.floor((Date.now() - ts) / 60000);
    if (m < 1) return "방금";
    if (m < 60) return m + "분 전";
    const h = Math.floor(m / 60);
    if (h < 24) return h + "시간 전";
    return Math.floor(h / 24) + "일 전";
  }
  function fmtDur(ms) {
    const m = Math.floor(ms / 60000);
    const h = Math.floor(m / 60);
    if (h >= 1) return h + "시간 " + (m % 60) + "분";
    return m + "분";
  }
})();

"use strict";
const S = chrome.storage.local;

function esc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function laPeak(){
  const f=new Intl.DateTimeFormat("en-US",{timeZone:"America/Los_Angeles",weekday:"short",hour:"numeric",hour12:false});
  const p=f.formatToParts(new Date());
  const wd=p.find(x=>x.type==="weekday").value;
  let hr=parseInt(p.find(x=>x.type==="hour").value,10); if(hr===24)hr=0;
  const m={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
  const dow=m[wd];
  return dow>=1&&dow<=5&&hr>=5&&hr<11;
}

S.get(["cmds","usage"],(r)=>{
  const peak=laPeak();
  document.getElementById("peak").innerHTML =
    `<div class="peak ${peak?"on":"off"}"><b>${peak?"피크 시간대":"여유 시간대"}</b> · ${peak?"채팅 세션 소모 빠름":"무거운 작업 적기"}</div>`;

  const u=r.usage;
  const uEl=document.getElementById("usage");
  if(!u){
    uEl.innerHTML=`<div class="muted">아직 사용량을 못 읽었어요. 아래에서 사용량 페이지를 한 번 열면 자동으로 읽어옵니다.</div>`;
  }else{
    document.getElementById("plan").textContent=u.plan?"· "+u.plan:"";
    const s=u.session||{pct:0,reset:""};
    let html=`<div class="row">
      <div class="top"><span class="lbl">현재 세션 · 5시간</span><span class="pct">${s.pct}%</span></div>
      <div class="bar${s.pct>=85?" hot":""}"><i style="width:${s.pct}%"></i></div>
      ${s.reset?`<div class="reset">${esc(s.reset)}</div>`:""}
    </div>`;
    (u.weekly||[]).forEach(w=>{
      html+=`<div class="row">
        <div class="top"><span class="lbl">${esc(w.label||"모델")}</span><span class="pct">${w.pct}%</span></div>
        <div class="bar${w.pct>=85?" hot":""}"><i style="width:${w.pct}%"></i></div>
        ${w.reset?`<div class="reset">${esc(w.reset)}</div>`:""}
      </div>`;
    });
    uEl.innerHTML=html;
  }

  const cmds=r.cmds||[];
  const listEl=document.getElementById("list");
  const searchEl=document.getElementById("search");
  function draw(){
    const q=searchEl.value.trim().toLowerCase();
    const items=cmds.filter(c=>!q||c.text.toLowerCase().includes(q)||(c.desc||"").toLowerCase().includes(q)||(c.cat||"").toLowerCase().includes(q));
    if(!items.length){listEl.innerHTML=`<div class="muted">일치하는 명령어가 없어요.</div>`;return;}
    const cats=[...new Set(items.map(c=>c.cat))];
    listEl.innerHTML=cats.map(cat=>
      `<div class="cat">${esc(cat)}</div>`+
      items.filter(c=>c.cat===cat).map(c=>
        `<div class="cmd" data-t="${esc(c.text)}"><span class="t">${esc(c.text)}</span><span class="c">복사됨</span></div>`).join("")
    ).join("");
    listEl.querySelectorAll(".cmd").forEach(n=>n.addEventListener("click",()=>{
      navigator.clipboard.writeText(n.dataset.t).then(()=>{n.classList.add("copied");setTimeout(()=>n.classList.remove("copied"),900);});
    }));
  }
  searchEl.addEventListener("input",draw);
  draw();
});
